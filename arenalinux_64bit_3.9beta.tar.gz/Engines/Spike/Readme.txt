This is the readme file of the linux-beta version of Spike1.2 Turin.

The linux-beta version of Spike1.2 Turin is the same engine as Spike1.2 Turin for windows except for two things:

First the linux version does not have a book linked to it. The book is in an extra file that is distributed with spike. Second there is no configuration program that brings a graphical user interface for modifying the configuration file of spike (spike.cnfg). You have to edit it manually with a text editor or leave it unchanged. 

Chess GUI
Spike is only a chess engine without a grapical user interface. Thus you have to use any availiable graphical interface and install Spike on it. 
The linux-beta version has been tested with xboard. Please read the xboard documentation for infos how to use xboard with new chess engines. One way to do is to copy spike in the xboard directory and call (from command line):
xboard -fcp ./spike

Installation
For installation simply copy all file of spike in any directory you whant to start spike from. If you whant to use tablebases please enter the tablebase path in the spike.cnfg file.

Report Errors?
If you whant to report errors on Spike1.2 Turin linux-beta, please use the feedback formula on the spike web-page:

http://spike.lazypics.de/

Have fun! 
