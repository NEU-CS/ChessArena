#!/bin/bash

#
# copy font files to user folder, so that Arena can use it, if running under current user:

mkdir ~/.fonts
cp *.TTF ~/.fonts
cp *.ttf ~/.fonts

# please restart Arena after the command is finished
 

