Titus 2.4  Developed for the Arena GUI December 16, 2008

Author: Kevin Frayer

Titus 2.4 is a small broad comprehensive opening book designed to reflect current chess engine opening theory. It is composed from 10,943 rated games between engines chess players with verified Elo's of 2740 to 3030.

With the imposed default book settings the strength is probably better against other known opening books. However a greater variety my be induced by moving the win percentage slid bar a bit to the right.